from setuptools import setup

setup(name="Prueba",  # Nombre
    version="1.0",  # Versión de desarrollo
    description="Paquete de prueba",  # Descripción del funcionamiento
    author="Alejo",  # Nombre del autor
    author_email='me',  # Email del autor
    license="",  # Licencia: MIT, GPL, GPL 2.0...
    url="http://ejemplo.com",  # Página oficial (si la hay)
    packages=['Paquetes_Tarea_3'],
    install_requires=["PIL"],
)
